package com.womackkyana.njfoodtrucksrusapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.navigation.findNavController
import androidx.navigation.ui.setupActionBarWithNavController
import com.womackkyana.njfoodtrucksrusapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //
        replaceFragment(Home())



//Bottom Navigation displays the fragments after they are pressed by the user
        binding.bottomNavigationView.setOnItemSelectedListener {
            when (it.itemId) {

                R.id.home -> replaceFragment(Home())
                R.id.map -> replaceFragment(Map())
                R.id.rewards -> replaceFragment(Rewards())
                R.id.contact -> replaceFragment(Contact())

                else -> {

                }

            }

            true

        }




    }

    //Implementing what to instruct the fragment to do
    private fun replaceFragment(fragment: Fragment) {

        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame_layout, fragment)
        fragmentTransaction.commit()


    }


}
