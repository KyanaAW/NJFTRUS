package com.womackkyana.njfoodtrucksrusapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton




        class Map : Fragment(), OnMapReadyCallback {

            //Coordinates for the food truck locations
            private lateinit var map: GoogleMap
            val PizzaVita = LatLng(40.72899656183156, -74.35512201943104)
            val RodgersRealBBQ = LatLng(40.588979220412085, -74.26593196124833)
            val SteakAndTake = LatLng(40.720558243303714, -74.20331340519992)
            val KissCakeCup = LatLng(40.730173303797535, -74.22021897473392)



            //Different arrays to have display their own information
            private var locationArrayList: ArrayList<LatLng>? = null
            private var locationArrayList1: ArrayList<LatLng>? = null
            private var locationArrayList2: ArrayList<LatLng>? = null
            private var locationArrayList3: ArrayList<LatLng>? = null



            override fun onCreateView(
                inflater: LayoutInflater, container: ViewGroup?,
                savedInstanceState: Bundle?,
            ): View? {


//The bottom nav disappears when the map fragment is pressed.
                val view =
                    requireActivity().findViewById<BottomNavigationView>(R.id.bottomNavigationView)

                view.visibility = View.GONE


                val rootView = inflater.inflate(R.layout.fragment_map, container, false)


                // After pressing the button on the home fragment, take the user to the map fragment(in progress)
                //val buttonRedirect = rootView.findViewById<Button>(R.id.btnBack)
                //buttonRedirect.setOnClickListener {

                    //Navigation.findNavController(rootView).navigate(R.id.goFromAction_Map2_to_Home2) }


                val mapFragment =
                    childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
                mapFragment.getMapAsync(this)


                //Takes coordinates of the arrays and displays them on the map
                locationArrayList = ArrayList()
                locationArrayList1 = ArrayList()
                locationArrayList2 = ArrayList()
                locationArrayList3 = ArrayList()




                locationArrayList!!.add(PizzaVita)
                locationArrayList1!!.add(RodgersRealBBQ)
                locationArrayList2!!.add(SteakAndTake)
                locationArrayList3!!.add(KissCakeCup)






                return rootView




            }


            override fun onMapReady(googleMap: GoogleMap) {

                map = googleMap
                for (i in locationArrayList!!.indices) {
                    //Includes the information for the markers
                    map.addMarker(
                        MarkerOptions().position(locationArrayList!![i]).title("PIZZA VITA")
                            .snippet("OPENS AT 11:30AM TO 8:30PM")

                    )
                    map.addMarker(
                        MarkerOptions().position(locationArrayList1!![i]).title("New Marker")
                            .snippet("INSERT INFO HERE")
                    )
                    map.addMarker(
                        MarkerOptions().position(locationArrayList2!![i]).title("New Marker")
                            .snippet("INSERT INFO HERE")
                    )

                    map.addMarker(
                        MarkerOptions().position(locationArrayList3!![i]).title("New Marker")
                            .snippet("INSERT INFO HERE")
                    )



                    map.animateCamera(CameraUpdateFactory.zoomTo(18.0f))
                    map.moveCamera(CameraUpdateFactory.newLatLng(locationArrayList!!.get(i)))


// Allows user to access zoom controls
                    googleMap.uiSettings.isZoomControlsEnabled = true
                    googleMap.uiSettings.isCompassEnabled = true


                }
            }
        }





